﻿namespace Proyecto_Tienda_Virtual.Models
{
    public class CarryoutViewModel
    {
       public List<Carryout> carryoutList { get; set; }
       public  Carryout Carryout { get; set; }

       
    }
}
